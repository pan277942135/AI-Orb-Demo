# Water World V2.1 — Source Driven Calibration Report

Master SHA-256: `fef8225a7322aa9edf77d2c753efe51af2189384e757eb0e974a68a88f44c589`  
Source: GitHub branch `assets/water-world-v2-v21-calibration`, commit `1662bbf9de671b0bb1fa5ce1891a1df3e49703b6`.

The raw 1254×1254 RGB PNG was decoded from its immutable GitHub commit and its byte count, mode, dimensions and SHA-256 matched the supplied source lock. The original 65 V2 archive members are copied byte-for-byte into `02_CALIBRATED_ASSETS/V2_ORIGINAL`; the source V2 ZIP and prior 21/21 Validator and 47-node/28-dependency results were not regenerated.

## Geometry results

- Sphere center `626.48, 596.34` px, radius `422.30` px; outer contour fit p95 residual `2.00` px.
- Inner core radius `395.75` px, confidence MEDIUM_LOW due glass and water reflection overlap.
- Four fish source ROIs and measured active-pixel masks are in `01_ANALYSIS/master_fish_geometry.json`; pale fin extents are recorded separately from warm-pixel segmentation.
- Five Resident curves are traced from hue/saturation pixels within the legacy semantic corridors. Same-color crossings remain explicitly ambiguous; static geometry only.
- Plant and rock masks are source-local segmentation with confidence MEDIUM_LOW; boundaries include translucent foliage and contact-shadow uncertainty.

## V2 asset decisions

| Resource | Decision | Evidence |
|---|---|---|
| 65 original V2 files | KEEP_SOURCE_UNMODIFIED | Copy SHA verification: PASS (65/65) |
| Fish placements | RECALIBRATE_COPY | Four full-resolution master boxes; source-mask IoU in visual metrics |
| Resident curves/widths | RECALIBRATE_COPY | Pixel chroma trace; per-resident confidence and path metrics included |
| Sphere/glass geometry | RECALIBRATE_COPY | Robust circle fit and inward radial edge analysis |
| Plants/rocks | RECALIBRATE_COPY | Source-local masks and registered bounding boxes; confidence MEDIUM_LOW |
| Water/lighting/bubbles mappings | RECALIBRATE_COPY | Pixel registrations and source layer mapping; intensity/decomposition partly unresolved |

## Static validation

Actual visual metric gates: `{"sphere_iou": "PASS", "sphere_center_error_over_diameter": "PASS", "sphere_diameter_error": "PASS", "fish_iou": "FAIL", "fish_center_error_over_canvas": "PASS", "resident_bidirectional_chamfer_over_radius": "FAIL", "resident_width_error": "FAIL", "plant_iou": "FAIL", "rock_iou": "FAIL"}`.  
Failed gate keys: `fish_iou, resident_bidirectional_chamfer_over_radius, resident_width_error, plant_iou, rock_iou`. Thresholds are unchanged. The independent CPU composition uses V2 background, water, fish, plants, rocks, bubble and Resident assets; the verified master is not used as a render layer. It does not claim GPU output or dynamic fidelity.
