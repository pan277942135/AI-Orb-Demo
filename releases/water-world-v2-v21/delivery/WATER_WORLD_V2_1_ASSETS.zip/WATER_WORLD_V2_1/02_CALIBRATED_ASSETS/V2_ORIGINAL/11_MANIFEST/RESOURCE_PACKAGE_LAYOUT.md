# Package layout

- `00_MASTER/`: user SOURCE LOCK record; raw master bytes were not available locally.
- `01_BACKGROUND/`: separate generated background.
- `02_RESIDENT/`: five SVG/JSON ribbon curves.
- `03_SPHERE/`: outer, cavity, shell, and front/back glass masks plus estimated geometry.
- `04_WATER/`: interior water plate, caustics, normal, and relative depth.
- `05_FISH/`: four RGBA fish, UV meshes and approximate scene positions.
- `06_PLANTS/`: left and right plant cutouts with masks and placements.
- `07_ROCKS/`: 3-object generated atlas, individual crops, masks and placements.
- `08_LIGHTING/`, `09_BUBBLES/`: lighting rig and bubble elements.
- `10_DEPTH/`: 16-bit relative depth and per-object alpha occlusion masks.
- `11_MANIFEST/`: asset inventory, generation ledger, checksums, scene graph, validation and acceptance records.
- `12_PREVIEW/`: static independent-asset reconstruction preview.
