# WATER WORLD V2 能力预检

检查时间：2026-11-25（UTC）

| 能力 | 状态 | 本环境证据与限制 |
|---|---|---|
| 参考图引导式图像生成 | AVAILABLE | `image_gen.imagegen` 可使用本轮最近的对话上传图像进行逐项生成/编辑。模型版本、内部参数未暴露，记为 `UNAVAILABLE`。 |
| 独立 RGBA 生成 | LIMITED | 支持 `transparent_background=true`；每个输出需检查 alpha 与边缘污染。 |
| 输出分辨率 | LIMITED | 工具接口不提供目标尺寸参数；需要记录实际输出分辨率，再决定资产是否可用。 |
| 矢量几何重建 | AVAILABLE | 可用程序生成 SVG/Bezier 与 JSON 几何，基于母版画布进行坐标归一化。 |
| PNG / RGBA / Mask / Normal / 16-bit Depth 处理 | AVAILABLE | Pillow、NumPy、SciPy 与 ImageMagick 可用，可生成无损 PNG、8-bit mask、切线空间 normal 与 16-bit 相对深度。深度不是物理测量。 |
| Alpha Matting | LIMITED | `cv2`、`rembg` 不可用；工具可直接输出透明背景，输出边界仍须审核。 |
| 独立静态图层合成 | AVAILABLE | Pillow / ImageMagick 支持 RGBA 合成与差异图输出。 |
| 图像差异 / 完整性 | AVAILABLE | 可比较合成结果并计算资产 SHA256。母版 SHA 按用户要求豁免。 |
