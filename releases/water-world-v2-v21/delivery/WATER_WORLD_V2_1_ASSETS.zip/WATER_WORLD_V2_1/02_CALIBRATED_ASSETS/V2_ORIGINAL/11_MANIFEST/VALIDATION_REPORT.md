# Asset Package Validation

**Overall:** `PASS`

Checks cover generated package structure and file decoding. They do not establish pixel fidelity to the source master, because the master image is available only inline and its SHA was waived by the user.

| Check | Result | Evidence |
|---|---|---|
| `NO_EMPTY_FILES` | PASS | 62 files enumerated |
| `IMAGE_DECODE:04_WATER/waterbed.png` | PASS | decoded |
| `IMAGE_DECODE:04_WATER/water_relative_depth_16bit.png` | PASS | decoded |
| `IMAGE_DECODE:04_WATER/water_normal_tangent.png` | PASS | decoded |
| `IMAGE_DECODE:03_SPHERE/glass_shell_mask.png` | PASS | decoded |
| `IMAGE_DECODE:03_SPHERE/sphere_outer_mask.png` | PASS | decoded |
| `IMAGE_DECODE:03_SPHERE/glass_front_arc_mask.png` | PASS | decoded |
| `IMAGE_DECODE:03_SPHERE/cavity_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:03_SPHERE/glass_back_arc_mask.png` | PASS | decoded |
| `IMAGE_DECODE:05_FISH/fish_03.png` | PASS | decoded |
| `IMAGE_DECODE:05_FISH/fish_02.png` | PASS | decoded |
| `IMAGE_DECODE:05_FISH/fish_01.png` | PASS | decoded |
| `IMAGE_DECODE:05_FISH/fish_04.png` | PASS | decoded |
| `IMAGE_DECODE:01_BACKGROUND/background.png` | PASS | decoded |
| `IMAGE_DECODE:09_BUBBLES/bubble_sprite.png` | PASS | decoded |
| `IMAGE_DECODE:10_DEPTH/sphere_relative_depth_16bit.png` | PASS | decoded |
| `IMAGE_DECODE:12_PREVIEW/RECONSTRUCTION_PREVIEW.jpg` | PASS | decoded |
| `IMAGE_DECODE:07_ROCKS/rock_atlas.png` | PASS | decoded |
| `IMAGE_DECODE:04_WATER/caustics/caustics_height.png` | PASS | decoded |
| `IMAGE_DECODE:06_PLANTS/plant_right/plant_right.png` | PASS | decoded |
| `IMAGE_DECODE:06_PLANTS/plant_left/plant_left.png` | PASS | decoded |
| `IMAGE_DECODE:10_DEPTH/occlusion_masks/plant_left_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:10_DEPTH/occlusion_masks/fish_03_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:10_DEPTH/occlusion_masks/fish_04_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:10_DEPTH/occlusion_masks/fish_01_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:10_DEPTH/occlusion_masks/rock_03_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:10_DEPTH/occlusion_masks/rock_02_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:10_DEPTH/occlusion_masks/fish_02_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:10_DEPTH/occlusion_masks/rock_01_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:10_DEPTH/occlusion_masks/plant_right_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:07_ROCKS/masks/rock_03_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:07_ROCKS/masks/rock_02_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:07_ROCKS/masks/rock_01_alpha.png` | PASS | decoded |
| `IMAGE_DECODE:07_ROCKS/individual/rock_03.png` | PASS | decoded |
| `IMAGE_DECODE:07_ROCKS/individual/rock_01.png` | PASS | decoded |
| `IMAGE_DECODE:07_ROCKS/individual/rock_02.png` | PASS | decoded |
| `JSON_PARSE:11_MANIFEST/trim_report.json` | PASS | valid JSON |
| `JSON_PARSE:11_MANIFEST/scene_graph.json` | PASS | valid JSON |
| `JSON_PARSE:11_MANIFEST/asset_inventory.json` | PASS | valid JSON |
| `JSON_PARSE:11_MANIFEST/ASSET_MANIFEST.json` | PASS | valid JSON |
| `JSON_PARSE:08_LIGHTING/lighting_rig.json` | PASS | valid JSON |
| `JSON_PARSE:04_WATER/water_material.json` | PASS | valid JSON |
| `JSON_PARSE:03_SPHERE/sphere_geometry.json` | PASS | valid JSON |
| `JSON_PARSE:02_RESIDENT/residents.json` | PASS | valid JSON |
| `JSON_PARSE:05_FISH/fish_scene_placements.json` | PASS | valid JSON |
| `JSON_PARSE:06_PLANTS/plant_placements.json` | PASS | valid JSON |
| `JSON_PARSE:09_BUBBLES/bubble_placements.json` | PASS | valid JSON |
| `JSON_PARSE:07_ROCKS/rock_placements.json` | PASS | valid JSON |
| `JSON_PARSE:07_ROCKS/atlas_components.json` | PASS | valid JSON |
| `JSON_PARSE:05_FISH/meshes/fish_04_mesh.json` | PASS | valid JSON |
| `JSON_PARSE:05_FISH/meshes/fish_03_mesh.json` | PASS | valid JSON |
| `JSON_PARSE:05_FISH/meshes/fish_01_mesh.json` | PASS | valid JSON |
| `JSON_PARSE:05_FISH/meshes/fish_02_mesh.json` | PASS | valid JSON |
| `FOUR_FISH` | PASS | 4 cutouts |
| `FISH_RGBA_ALPHA:fish_03.png` | PASS | (976, 381), alpha 0..255 |
| `FISH_RGBA_ALPHA:fish_02.png` | PASS | (1301, 464), alpha 0..255 |
| `FISH_RGBA_ALPHA:fish_01.png` | PASS | (1680, 624), alpha 0..255 |
| `FISH_RGBA_ALPHA:fish_04.png` | PASS | (912, 367), alpha 0..255 |
| `TWO_PLANTS` | PASS | 2 cutouts |
| `THREE_ROCKS` | PASS | 3 cutouts |
| `FIVE_RESIDENTS` | PASS | 5 unique IDs |
| `SQUARE_BG:background.png` | PASS | (1254, 1254) |
| `SQUARE_BG:waterbed.png` | PASS | (1254, 1254) |
| `NORMAL_MAP` | PASS | RGB (512, 512) |
| `SPHERE_DEPTH_16BIT` | PASS | I;16 (1254, 1254) |
| `WATER_DEPTH_16BIT` | PASS | I;16 (512, 512) |
| `MESH_INDICES:fish_04_mesh.json` | PASS | 119 verts / 82 tris |
| `MESH_INDICES:fish_03_mesh.json` | PASS | 119 verts / 80 tris |
| `MESH_INDICES:fish_01_mesh.json` | PASS | 119 verts / 90 tris |
| `MESH_INDICES:fish_02_mesh.json` | PASS | 119 verts / 90 tris |
| `MANIFEST_PATHS` | PASS | 59 entries; missing=[] |
| `NO_MASTER_HASH` | PASS | master hash not computed; raw file not present |

**Not run:** master pixel comparison, exact geometry fitting, GPU render, Android integration, and animation QA.
