# Independent static composition

Run from the repository root: `PYTHONPATH=/tmp/wv21-opencv python tools/water-world-v2-1/analyze_recompose_master.py --package-root <package>` then `python tools/water-world-v2-1/canonical_metrics.py --package-root <package>` and `python tools/water-world-v2-1/finalize_inputs.py --package-root <package>`. This is a CPU composition from original V2 assets. The master is reference-only; masks and overlays are measurement evidence. See `visual_metrics.json` for the frozen thresholds and actual status.
