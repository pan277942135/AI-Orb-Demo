# Validator regression evidence — carried forward

The prior regression run recorded 21/21 PASS. Per the current instruction, the suite was not rerun. The prior missing-master case was an expected negative test from an earlier HEAD before the original PNG was imported. The current source is verified at SHA-256 `fef8225a7322aa9edf77d2c753efe51af2189384e757eb0e974a68a88f44c589`; current static acceptance is reported separately in `visual_acceptance_report.md` and `validation_manifest.json`.

This file is historical test evidence and does not describe the current source state.
