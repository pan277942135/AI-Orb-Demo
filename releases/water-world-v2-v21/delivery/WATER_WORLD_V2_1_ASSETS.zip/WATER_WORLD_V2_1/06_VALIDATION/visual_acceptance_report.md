# Water World V2.1 — Static Visual Acceptance

Status: **FAIL** (`WORK1_5_VALIDATION_FAILED` when any hard gate fails).

Reference: `fef8225a7322aa9edf77d2c753efe51af2189384e757eb0e974a68a88f44c589` (verified source PNG, 1254×1254 RGB). Recomposition: independent V2 asset CPU scene, same 1254×1254 pixels. GPU_RENDER: NOT_RUN.

| Metric | Measured | Required | Status |
|---|---:|---:|---|
| Sphere IoU | 0.994769 | ≥0.98 | PASS |
| Sphere center error / diameter | 0.001045 | ≤0.005 | PASS |
| Sphere diameter error | 0.000448 | ≤0.01 | PASS |
| Fish IoU | {'WW_FISH_01': 0.4189102564102564, 'WW_FISH_02': 0.30696959344038266, 'WW_FISH_03': 0.3443425076452599, 'WW_FISH_04': 0.4105991883504416} | each ≥0.90 | FAIL |
| Fish center error / canvas | {'WW_FISH_01': 0.0014779210331334303, 'WW_FISH_02': 0.003051052881316533, 'WW_FISH_03': 0.0013359329527292117, 'WW_FISH_04': 0.0007610972564930666} | each ≤0.01 | PASS |
| Resident bidirectional Chamfer / radius | {'G01': 0.013569892646397153, 'G02': 0.00909883629962014, 'A01': 0.013141318044706807, 'A02': 0.009853598492286583, 'C01': 0.028323699261833892} | each ≤0.015 | FAIL |
| Resident width error | {'G01': 0.03430510235642324, 'G02': 0.03020422961516771, 'A01': 0.0, 'A02': 0.0, 'C01': 0.0} | each ≤0.05 | PASS |
| Plant IoU | {'plant_left': 0.11967664258685931, 'plant_right': 0.18667480729603908} | each ≥0.85 | FAIL |
| Rock IoU | {'rock_01': 0.6290402672444926, 'rock_02': 0.46589641789713165, 'rock_03': 0.32685688908626626} | each ≥0.85 | FAIL |

Comparison files: `03_STATIC_RECOMPOSITION/static_recomposition.png`, `master_reference.png`, `master_overlay.png`, `difference_heatmap.png`, `region_comparison.png`, `visual_metrics.json`. Segmentation confidence/limitations are recorded in `visual_metrics.json` and the geometry JSONs.

**Result:** the measured hard gates did not all pass; no threshold was changed. Failing keys: fish_iou, resident_bidirectional_chamfer_over_radius, plant_iou, rock_iou.
