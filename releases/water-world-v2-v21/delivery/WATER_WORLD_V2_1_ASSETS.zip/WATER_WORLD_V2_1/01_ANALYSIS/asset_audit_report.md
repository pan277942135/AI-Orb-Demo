# V2 Source Asset Audit — master-calibrated update

The immutable source archive remains 11,678,323 bytes with SHA-256 `6b85708fc5eccf8f5c130b1d9c48bfd59abc829b178db9dd0729b4ef7b065095`. Its previously reported 65 entries and 63/63 embedded hashes are carried forward; this turn did not rerun that archive audit.

The verified master source SHA-256 is `fef8225a7322aa9edf77d2c753efe51af2189384e757eb0e974a68a88f44c589`. All 65 extracted V2 files were copied byte-for-byte into `02_CALIBRATED_ASSETS/V2_ORIGINAL/`. Source-driven placement and geometry copies are in `02_CALIBRATED_ASSETS/`. The visual metrics are not all passing: fish, plants, rocks and one Resident Chamfer gate fail. The original source assets are preserved, not certified as visually accepted.
