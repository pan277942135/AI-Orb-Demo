# TAB2 Perimeter V1.1 — editable resource split

Source: pan277942135/AI-Orb-Demo @ 008e47de6d798517085ad2e459d5dac6153799db

This ZIP contains **actual isolated editable SVG vector groups** from the committed V1.1 resource map, plus a geometry/motion export. They are **schematic design guides**; the frozen master is a flattened RGB PNG, so it is not possible to faithfully recover separate original L1-L4 textures or Alpha by cropping.

Files:
- layers/L1..L4.svg: four independently editable vector groups.
- geometry/PHOTO_FRAME.svg and ORB_PHOTO_CONNECTOR.svg: separate guide paths.
- preview/L1_L4_COMPOSITE_VECTOR.svg: all four overlay groups without the photo.
- geometry/photo_geometry.json: approximate frame bounds and editable path data.
- motion/kf01_kf06.json: frozen motion and no-seam looping contract in machine-readable form.
- reference/: frozen contracts and source integrity metadata.

**Original master:** https://raw.githubusercontent.com/pan277942135/AI-Orb-Demo/008e47de6d798517085ad2e459d5dac6153799db/docs/tab2/assets/TAB2_P0_HIGH_FIDELITY_MASTER_V1.png
SHA-256: a37819bba6b144ca7fec27ace55e5b319c41e67b89a11e70d51200bce8749d67
It was already verified in PR #7. It is referenced rather than re-encoded in this ZIP because the GitHub binary download endpoint is unavailable to this environment.

For production Android/GLES, use the current repository’s PerimeterPathGeometry, PerimeterArcLengthTable, PerimeterWaterLightRenderer and V1.1 contracts. Do not import these paths as exact shader meshes or claim Alpha fidelity/GPU acceptance.
