TAB2 V2 reference-derived GPU-sampleable RGBA normal flow textures and KF01-KF06 CPU previews. Original RGB does not contain true layer alpha; visual GPU QA NOT_RUN.
