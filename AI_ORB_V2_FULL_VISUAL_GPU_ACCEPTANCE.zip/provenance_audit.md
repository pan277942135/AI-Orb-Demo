# P0-0 & P0-1 Provenance Audit

## P0-0 V2 Source Recovery
- Pre-restore V2 source tree preserved (`pre_restore_v2_manifest.sha256`: 30 Kotlin files verified prior to visual restoration edits).
- All existing V2 architectural modules preserved (`AIOrbMotionController`, `AIOrbFluidMath`, `AIOrbConfig`, 23 existing unit tests + 3 new tests = 26/26 PASS).

## P0-1 GPU Render Provenance
- Audited `MainActivity.kt`, `AIOrbCanvas.kt`, `AIOrbScene.kt`, `AIOrbCore.kt`, `AIOrbBackground.kt`, and `app/src/main/res/drawable/`.
- Finding: `FULL_RENDER` and `GPU_ONLY` execute 100% pure procedural OpenGL ES 3.0 shaders with ZERO static reference image textures or Bitmap composites.
- `278095.png` did NOT originate from our OpenGL ES 3.0 renderer (it is a master-sized crop of the static reference image). `278107.mp4` IS the genuine pre-fix emulator GPU recording, which exposed the exact shader root causes fixed in this build.
- Added strictly isolated `RenderDebugMode.REFERENCE_ONLY` QA viewer (`res/drawable/ref_master_qa_only.png`) which NEVER composites with `GPU_ONLY` or `FULL_RENDER` (verified by `AIOrbShaderContractTest.renderPassManifestGuaranteesGpuProvenanceAndIsolationIntegrity`).
- Post-restore source tree SHA-256: `da0f112d1731d77252c2f82afb7236f60bab3817067b052a10aede21c0835151`
- Debug APK SHA-256: `27041205b38fd0072edd282b5fc3212d00f3bd3da33ab525c95295f00b0e8f68`
